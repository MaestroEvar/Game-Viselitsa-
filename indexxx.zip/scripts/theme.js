document.addEventListener('DOMContentLoaded', function() {
    // Переключение темы
    const themeToggle = document.getElementById('theme-toggle');
    themeToggle.addEventListener('change', function() {
        if (this.checked) {
            document.body.setAttribute('data-theme', 'dark');
        } else {
            document.body.removeAttribute('data-theme');
        }
    });

    const letterInput = document.getElementById('letter-input');
    const letterDisplay = document.getElementById('letter-display');
    const errorMessage = document.getElementById('error-message');
    const submitButton = document.getElementById('submit-letter');
    
    // Загаданное слово, делаем массив для пустых полей букв
    const secretWord = "кот";
    let guessedLetters = new Array(secretWord.length).fill('_');
    
    // Обновляем отображение угаданных букв
    function updateGuessedLetters() {
        letterDisplay.textContent = `Угадай слово: ${guessedLetters.join(' ')}`;
    }
    
    // Загружаем пустые поля для букв при загрузке страницы
    updateGuessedLetters();

    letterInput.addEventListener('input', function() {
        //Проверка на то что буква русская
        const isValid = /^[а-яА-ЯёЁ]?$/.test(this.value);
        //В противном случае, выводится ошибка, блокируется кнопка, и поле ввода очищается
        if (!isValid) {
            errorMessage.style.display = 'block';
            this.value = '';
            submitButton.disabled = true;
            return;
        }
        //При правильном вводе сообщение об ошибке исчезает
        errorMessage.style.display = 'none';
        //кнопка снова блокируется до следующего ввода
        submitButton.disabled = this.value.length === 0;
    });
    //Кнопка отправки буквы
    submitButton.addEventListener('click', function() {
            const userLetter = letterInput.value.toLowerCase();
            let letterFound = false;
            // Проверка каждой буквы в слове
            for (let i = 0; i < secretWord.length; i++) {
                //Меняем символ "_" на угаданную букву
                if (secretWord[i] === userLetter) {
                    guessedLetters[i] = userLetter;
                    letterFound = true;
                }
            }
            
            if (letterFound) {
                letterDisplay.textContent = `Правильно! Угаданные буквы: ${guessedLetters.join(' ')}`;
                
                // Проверяем, отсутствие "_"
                if (!guessedLetters.includes('_')) {
                    letterDisplay.textContent = `Поздравляем! Вы угадали слово: ${secretWord}`;
                }
            } else {
                letterDisplay.textContent = `Ошибка! Буквы "${userLetter.toUpperCase()}" нет в слове. Угаданные буквы: ${guessedLetters.join(' ')}`;
            }
            //Очищаем поле и блокируем кнопку, для следующего ввода
            letterInput.value = '';
            submitButton.disabled = true;
    });
});